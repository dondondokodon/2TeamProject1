﻿#include "Laser.h"
#include"Collision.h"
#include <algorithm>
#include<imgui.h>
#include"StageObjectManager.h"
#include"math.h"
#include"EffectManager.h"
#include "Player.h"

using namespace DirectX;

void LaserBeam::SetMirrorPlayers(Player** players, int count)
{
	mirrorPlayers = players;
	mirrorPlayerCount = count;
}


void LaserBeam::Update(float elapsedTime) 
{
	segments.clear();

	DirectX::XMFLOAT3 start = origin;
	DirectX::XMFLOAT3 dir = direction;

	// 反射直後の次の線分だけ、本体Stop判定を無視するPlayer2
	// 反射点から少し進めても、まだPlayer2本体の判定内に残ることがあるため
	Player* ignoreBodyStopPlayer = nullptr;

	for (int i = 0; i < maxReflection; i++)
	{
		// 無視するのはこの1本だけ。次の反射/停止には持ち越さない
		Player* bodyStopIgnoreForThisSegment = ignoreBodyStopPlayer;
		ignoreBodyStopPlayer = nullptr;

		DirectX::XMFLOAT3 end =
		{
			start.x + dir.x * maxLength,
			start.y + dir.y * maxLength,
			start.z + dir.z * maxLength
		};

		DirectX::XMFLOAT3 hitPos, hitNormal;

		// この線分で反射したPlayer2。次の線分で本体Stopだけ一度無視するために使う
		Player* reflectedPlayer = nullptr;

		//    StageObjectManager  ?  C L   X g  ?     
		RayHitResult hit = StageObjectManager::Instance().RayCast(start, end, hitPos, hitNormal);

		// ステージオブジェクトに当たった距離を記録、後でロボットの鏡にも当たった場合より手前にある方を優先するから
		float stageHitDistSq = FLT_MAX;
		if (hit.hit)
		{
			float dx = hitPos.x - start.x;
			float dy = hitPos.y - start.y;
			float dz = hitPos.z - start.z;
			stageHitDistSq = dx * dx + dy * dy + dz * dz;
		}

		// Player2はStageObjectではないので、StageObjectManagerのRayCastには含まれない
		// そのためレーザー側でプレイヤー配列を見て、ロボットの仮想鏡面/本体Stopを判定する
		for (int playerIndex = 0; playerIndex < mirrorPlayerCount; ++playerIndex)
		{
			Player* player = mirrorPlayers[playerIndex];

			// プレイヤーが存在しない、または鏡を持っていない場合は判定しない
			if (!player || !player->IsLaserMirror()) continue;

			DirectX::XMFLOAT3 playerHitPos;
			DirectX::XMFLOAT3 playerHitNormal;

			// ロボット正面の仮想鏡面に、このレーザー線分が当たるか調べる
			bool mirrorHit = player->RayCastLaserMirror(start, end, playerHitPos, playerHitNormal);

			if (mirrorHit)
			{
				// レーザー開始位置から、ロボット鏡面のヒット位置までの距離を求める
				float dx = playerHitPos.x - start.x;
				float dy = playerHitPos.y - start.y;
				float dz = playerHitPos.z - start.z;
				float playerHitDistSq = dx * dx + dy * dy + dz * dz;

				// ステージオブジェクトより手前でロボットの鏡に当たった場合だけ、今回のヒット結果をロボット鏡面の反射として扱う
				if (playerHitDistSq < stageHitDistSq)
				{
					hit.hit = true;

					// ロボットはStageObjectではないので object は nullptr にする
					hit.object = nullptr;

					// レーザーの通常反射処理に流すため、reflection として扱う
					hit.type = RayHitType::reflection;
					hit.hitPos = playerHitPos;
					hit.hitNormal = playerHitNormal;

					hitPos = playerHitPos;
					hitNormal = playerHitNormal;
					stageHitDistSq = playerHitDistSq;
					reflectedPlayer = player;

					DirectX::XMVECTOR vIn = DirectX::XMLoadFloat3(&dir);       // 入射ベクトル
					DirectX::XMVECTOR vNorm = DirectX::XMLoadFloat3(&hitNormal); // 鏡の法線
					// DirectXMathの反射ベクトル計算関数を使う
					DirectX::XMVECTOR vRef = DirectX::XMVector3Reflect(vIn, vNorm);
					DirectX::XMStoreFloat3(&hit.reflectionDir, vRef); // 計算結果を代入
				}

				// 反射できる時は、ロボット本体のStop判定は見ない
				continue;
			}

			// 同じPlayer2の本体Stop判定だけ1回無視し、反射レーザーがすぐ止まらないようにする
			if (player == bodyStopIgnoreForThisSegment) continue;

			// 反射できなかった時だけ、Player2本体でレーザーを止める。Player2の周りを少し大きめの円柱として扱う
			DirectX::XMFLOAT3 robotPos = player->GetPosition();
			DirectX::XMFLOAT3 robotCenter = {
				robotPos.x,
				robotPos.y + player->GetHeight() * 0.5f,
				robotPos.z
			};

			DirectX::XMFLOAT3 laserVec = {
				end.x - start.x,
				end.y - start.y,
				end.z - start.z
			};

			float laserLenSq =
				laserVec.x * laserVec.x +
				laserVec.y * laserVec.y +
				laserVec.z * laserVec.z;

			if (laserLenSq > 0.0001f)
			{
				float t =
					((robotCenter.x - start.x) * laserVec.x +
						(robotCenter.y - start.y) * laserVec.y +
						(robotCenter.z - start.z) * laserVec.z) / laserLenSq;

				t = std::clamp(t, 0.0f, 1.0f);

				DirectX::XMFLOAT3 closest = {
					start.x + laserVec.x * t,
					start.y + laserVec.y * t,
					start.z + laserVec.z * t
				};

				const float bodyRadius = player->GetRadius() + radius + 0.35f;
				const float bodyHalfHeight = player->GetHeight() * 0.6f;

				float dx = closest.x - robotCenter.x;
				float dz = closest.z - robotCenter.z;
				float dy = fabsf(closest.y - robotCenter.y);

				if (dx * dx + dz * dz <= bodyRadius * bodyRadius && dy <= bodyHalfHeight)

				{
					float bodyHitDistSq =
						(closest.x - start.x) * (closest.x - start.x) +
						(closest.y - start.y) * (closest.y - start.y) +
						(closest.z - start.z) * (closest.z - start.z);

					if (bodyHitDistSq < stageHitDistSq)
					{
						hit.hit = true;
						hit.object = nullptr;
						hit.type = RayHitType::Stop;
						hit.hitPos = closest;

						// Player2本体で止めた時のヒットエフェクト用の向き
						// 上向き(0,1,0)にするとエフェクトが上から出るので、レーザーが来た方向へ向ける
						hit.hitNormal = { -dir.x, -dir.y, -dir.z };

						hitPos = closest;
						hitNormal = hit.hitNormal;
						stageHitDistSq = bodyHitDistSq;
					}
				}
			}
		}

		//反射
		if (hit.object)
		{
			// レーザー回転中でも、鏡だけは ReallyHit を通して反射方向を計算する。
			// ここを飛ばすと reflectionDir が入らず、鏡に当たっても反射しないことがある。
			if (!isRotating || hit.type == RayHitType::reflection)
			{
				//それぞれのヒット条件と見比べる
				hit = hit.object->ReallyHit(dir, hitPos, hitNormal);
				if (!isRotating && hit.hit)
				{
					hit.object->OnHit(true); //ヒット通知
				}
			}
		}
		else if (!hit.hit)
		{
			 segments.push_back({ start, end,hitNormal,false });
			 break;
		}


		if (hit.type == RayHitType::reflection)
		{
			segments.push_back({
	        start,
	        hitPos,
	        hit.hitNormal,
	        true
				});

			dir = hit.reflectionDir;
			ignoreBodyStopPlayer = reflectedPlayer;

			// 次のレーザーの開始位置を、反射点から少しだけ進める
			// 同じ位置から再スタートすると、同じ鏡にもう一度当たってしまうことがあるから
			start = {
				hitPos.x + dir.x * 0.02f,
				hitPos.y + dir.y * 0.02f,
				hitPos.z + dir.z * 0.02f
			};
		}
		else if (hit.type == RayHitType::Stop)
		{
			ignoreBodyStopPlayer = nullptr;

			// 反射しない物体に当たった場合は、当たった位置でレーザーを止める
			segments.push_back({ start, hitPos,hitNormal,true });
			break;
		}
		else if (hit.type == RayHitType::None)
		{
			//貫通するものに当たった場合はそこまでのlaserを作って貫通後のレーザーを計算する
			//segments.push_back({ start, hitPos,hitNormal,true });
			//start = hitPos;
			continue;
		}

	}
}

void LaserBeam::Render()
{
	// 回転中はレーザーエフェクトを止めて、このフレームでは再生しない。
	// 止めた直後にPlayし直すと、回転中ずっと生成/停止を繰り返して重くなる。
	if (isRotating) {
		if (isEffectPlaying) {
			//StopEffect();
			//isEffectPlaying = false;
			StopBackEffect();
		}
		//return;
	}
	
	Effekseer::ManagerRef effekseerManager = EffectManager::Instance().GetEffekseerManager();

	if (!isEffectPlaying)
	{
		BackEffectHandle = laserBackEffect->Play(origin, 0.5f);

		// 1. 方向ベクトルから角度を計算
		float yaw = atan2f(direction.x, direction.z);
		float xzLen = sqrtf(direction.x * direction.x + direction.z * direction.z);
		float pitch = -atan2f(direction.y, xzLen);

		// 2. 素材が元々逆を向いているなら、180度（XM_PI）回転させて相殺する
		// yaw に対して XM_PI を加算する
		effekseerManager->SetRotation(BackEffectHandle, pitch, yaw + DirectX::XM_PI, 0.0f);
	}
	
	//セグメント数とエフェクト数の同期
	//反射が減った場合：余分なエフェクトを止める

	while (activeEffects.size() > segments.size()) {
		effekseerManager->StopEffect(activeEffects.back());
		activeEffects.pop_back();
	}

	for (size_t i = 0; i < segments.size(); ++i) {
		auto& seg = segments[i];
	
		DirectX::XMVECTOR s = DirectX::XMLoadFloat3(&seg.start);
		DirectX::XMVECTOR e = DirectX::XMLoadFloat3(&seg.end);
		float length = DirectX::XMVectorGetX(DirectX::XMVector3Length(DirectX::XMVectorSubtract(e, s)));
		DirectX::XMVECTOR dir = DirectX::XMVector3Normalize(DirectX::XMVectorSubtract(e, s));
	
		Effekseer::Handle handle;
	
		//足りない場合のみ新しくPlayする
		if (i >= activeEffects.size()) {
			handle = laserEffect.get()->Play(seg.start, 1.0f);
			activeEffects.push_back(handle);
		}
		else {
			handle = activeEffects[i];
		}
		
	
		//行列計算
		dir = DirectX::XMVectorNegate(dir);
		DirectX::XMVECTOR worldUp = DirectX::XMVectorSet(0, 1, 0, 0);
		if (fabsf(DirectX::XMVectorGetY(dir)) > 0.999f) {
			worldUp = DirectX::XMVectorSet(0, 0, 1, 0);
		}
		DirectX::XMVECTOR right = DirectX::XMVector3Normalize(DirectX::XMVector3Cross(worldUp, dir));
		DirectX::XMVECTOR up = DirectX::XMVector3Cross(dir, right);
	
		const float baseEffectSize = 28.0f;
		DirectX::XMMATRIX mat = DirectX::XMMATRIX(
			DirectX::XMVectorScale(right, 2.5f),
			DirectX::XMVectorScale(up, 2.5f),
			DirectX::XMVectorScale(dir, length / baseEffectSize),
			DirectX::XMVectorSetW(s, 2.5f)
		);
	
		Effekseer::Matrix43 effekMat;
		DirectX::XMFLOAT4X4 m;
		DirectX::XMStoreFloat4x4(&m, mat);
		effekMat.Value[0][0] = m._11; effekMat.Value[0][1] = m._12; effekMat.Value[0][2] = m._13;
		effekMat.Value[1][0] = m._21; effekMat.Value[1][1] = m._22; effekMat.Value[1][2] = m._23;
		effekMat.Value[2][0] = m._31; effekMat.Value[2][1] = m._32; effekMat.Value[2][2] = m._33;
		effekMat.Value[3][0] = m._41; effekMat.Value[3][1] = m._42; effekMat.Value[3][2] = m._43;
	
		// 毎フレーム、最新のセグメント行列をセット
		effekseerManager->SetMatrix(handle, effekMat);
	}

	//反射エフェクト
	//セグメント数とエフェクト数の同期
	int refrectionCount = segments.size();
	if (refrectionCount > 0 && segments[refrectionCount-1].hit == false)
		refrectionCount--;

	while(activeReflectEffects.size() > refrectionCount) {
		effekseerManager->StopEffect(activeReflectEffects.back());
		activeReflectEffects.pop_back();
	}

	for (size_t i = 0; i < refrectionCount; ++i) {
		auto& seg = segments[i];
		if (!seg.hit)break;

		DirectX::XMVECTOR s = DirectX::XMLoadFloat3(&seg.start);
		DirectX::XMVECTOR e = DirectX::XMLoadFloat3(&seg.end);
		float length = DirectX::XMVectorGetX(DirectX::XMVector3Length(DirectX::XMVectorSubtract(e, s)));
		DirectX::XMVECTOR dir = DirectX::XMVector3Normalize(DirectX::XMVectorSubtract(e, s));
		DirectX::XMFLOAT3 Direction;
		DirectX::XMStoreFloat3(&Direction, dir);

		Effekseer::Handle handle;

		//足りない場合のみ新しくPlayする
		if (i >= activeReflectEffects.size()) {
			handle = beamReflectEffect.get()->Play(seg.end, 1.0f);
			activeReflectEffects.push_back(handle);
		}
		else {
			handle = activeReflectEffects[i];
		}

		//角度計算
		// 1. 方向ベクトルから角度を計算
		float yaw = atan2f(seg.normal.x, seg.normal.z);
		float xzLen = sqrtf(seg.normal.x * seg.normal.x + seg.normal.z * seg.normal.z);
		float pitch = -atan2f(seg.normal.y, xzLen);

		// 座標を最新のヒット地点(seg.end)に更新する
		effekseerManager->SetLocation(handle, seg.end.x, seg.end.y, seg.end.z);

		// 2. 素材が元々逆を向いているなら、180度（XM_PI）回転させて相殺する
		// yaw に対して XM_PI を加算する
		effekseerManager->SetRotation(activeReflectEffects[i], pitch, yaw + DirectX::XM_PI, 0.0f);
	}

	
	isEffectPlaying = true;
}

//?f?o?b?O?pGUI?`??
void LaserBeam::DrawDebugGUI()
{
	if (ImGui::Begin("Beam", nullptr, ImGuiWindowFlags_None))
	{
		//?g?????X?t?H?[??
		if (ImGui::CollapsingHeader("Item", ImGuiTreeNodeFlags_DefaultOpen))
		{
			//??u
			ImGui::InputFloat3("dir", &direction.x);

			//????
			ImGui::InputFloat("maxLength", &maxLength);

			//????
			ImGui::InputFloat("radius", &radius);
		}
	}
	ImGui::End();
}

LaserHit LaserBeam::CheckHitAABB(const BoxCollider& box) const
{
	//if (isRotating)
	//	return LaserHit(); // ????????

	LaserHit result;
	//float bestDist = FLT_MAX;


	// AABB ?? min/max
	DirectX::XMFLOAT3 bmin =
	{
		box.GetCenter().x - box.GetSize().x * 0.5f,
		box.GetCenter().y - box.GetSize().y * 0.5f,
		box.GetCenter().z - box.GetSize().z * 0.5f
	};
	DirectX::XMFLOAT3 bmax =
	{
		box.GetCenter().x + box.GetSize().x * 0.5f,
		box.GetCenter().y + box.GetSize().y * 0.5f,
		box.GetCenter().z + box.GetSize().z * 0.5f
	};

	// ?S???????????????
	for (const auto& seg : segments)
	{
		DirectX::XMVECTOR s = DirectX::XMLoadFloat3(&seg.start);
		DirectX::XMVECTOR e = DirectX::XMLoadFloat3(&seg.end);
		DirectX::XMVECTOR dir = DirectX::XMVector3Normalize(DirectX::XMVectorSubtract(e,s));

		float segLen = DirectX::XMVectorGetX(DirectX::XMVector3Length(DirectX::XMVectorSubtract(e, s)));

		// AABB ???S
		DirectX::XMVECTOR boxCenter = DirectX::XMLoadFloat3(&box.GetCenter());
		DirectX::XMVECTOR v = DirectX::XMVectorSubtract(boxCenter, s);

		// ??????????_
		float t = DirectX::XMVectorGetX(DirectX::XMVector3Dot(v, dir));
		t = std::clamp(t, 0.0f, segLen);

		DirectX::XMVECTOR closestOnRay = DirectX::XMVectorAdd(s, DirectX::XMVectorScale(dir, t));

		// AABB ??????_
		DirectX::XMFLOAT3 rayPoint;
		DirectX::XMStoreFloat3(&rayPoint, closestOnRay);

		DirectX::XMFLOAT3 closestOnAABB =
		{
			std::clamp(rayPoint.x, bmin.x, bmax.x),
			std::clamp(rayPoint.y, bmin.y, bmax.y),
			std::clamp(rayPoint.z, bmin.z, bmax.z)
		};

		DirectX::XMVECTOR aabbP = DirectX::XMLoadFloat3(&closestOnAABB);

		// ????
		float dist = DirectX::XMVectorGetX(DirectX::XMVector3Length(DirectX::XMVectorSubtract(aabbP , closestOnRay)));


		float skin = 0.01f;

		if (dist <= radius - skin)
		{
			float hitDist = t;  //・ｽ・ｽ・ｽ・ｽ・ｽ・ｽﾌ具ｿｽ・ｽ・ｽ
			result.hit = true;

			float depth = radius - dist;

			// 押しすぎ防止
			float push = depth * 0.7f;

			// 最小保証
			push = max(push, 0.01f);

			result.penetration = push;

			// 法線
			DirectX::XMFLOAT3 dirOut =
			{
				box.GetCenter().x - rayPoint.x,
				box.GetCenter().y - rayPoint.y,
				box.GetCenter().z - rayPoint.z
			};

			DirectX::XMVECTOR n = DirectX::XMVector3Normalize(
				DirectX::XMLoadFloat3(&dirOut)
			);

			DirectX::XMStoreFloat3(&result.normal, n);

			return result;
		}
	  
	}

	return result;
	//return bestHit;
}

//・ｽ~・ｽ・ｽ・ｽﾆの費ｿｽ・ｽ・ｽ
LaserHit LaserBeam::CheckHitCylinder(const CylinderCollider& cylinder) const
{
	//if (isRotating)
	//	return LaserHit();

//	LaserHit result;
//
//	float halfH = cylinder.GetHeight() * 0.5f;
//	float cylR = cylinder.GetRadius();
//	DirectX::XMFLOAT3 center = cylinder.GetCenter();
//
//	for (const auto& seg : segments)
//	{
//		// ざっくり距離チェック。
//// 円柱中心がレーザー線分の範囲から明らかに遠い場合は、細かい判定をしない。
//		float minX = min(seg.start.x, seg.end.x) - (cylR + radius);
//		float maxX = max(seg.start.x, seg.end.x) + (cylR + radius);
//		float minY = min(seg.start.y, seg.end.y) - (halfH + radius);
//		float maxY = max(seg.start.y, seg.end.y) + (halfH + radius);
//		float minZ = min(seg.start.z, seg.end.z) - (cylR + radius);
//		float maxZ = max(seg.start.z, seg.end.z) + (cylR + radius);
//
//		if (center.x < minX || center.x > maxX ||
//			center.y < minY || center.y > maxY ||
//			center.z < minZ || center.z > maxZ)
//		{
//			continue;
//		}
//
//		DirectX::XMVECTOR s = XMLoadFloat3(&seg.start);
//		DirectX::XMVECTOR e = XMLoadFloat3(&seg.end);
//
//		DirectX::XMVECTOR segVec = XMVectorSubtract(e, s);
//		float segLen = XMVectorGetX(XMVector3Length(segVec));
//		if (segLen <= 0.0001f) continue;
//
//		DirectX::XMVECTOR dir = XMVectorScale(segVec, 1.0f / segLen);
//
//		// レーザー上の最近接点 p
//		DirectX::XMVECTOR c = XMLoadFloat3(&center);
//		float t = XMVectorGetX(XMVector3Dot(XMVectorSubtract(c, s), dir));
//		t = std::clamp(t, 0.0f, segLen);
//
//		DirectX::XMVECTOR pVec = XMVectorAdd(s, XMVectorScale(dir, t));
//
//		DirectX::XMFLOAT3 p;
//		DirectX::XMStoreFloat3(&p, pVec);
//
//		// Cylinder 上の最近接点 q
//		DirectX::XMFLOAT3 q;
//
//		// Y clamp
//		q.y = std::clamp(p.y, center.y - halfH, center.y + halfH);
//
//		// XZ 円
//		float dx = p.x - center.x;
//		float dz = p.z - center.z;
//		float len = sqrtf(dx * dx + dz * dz);
//
//		if (len > cylR)
//		{
//			q.x = center.x + dx / len * cylR;
//			q.z = center.z + dz / len * cylR;
//		}
//		else
//		{
//			q.x = p.x;
//			q.z = p.z;
//		}
//
//		DirectX::XMVECTOR qVec = XMLoadFloat3(&q);
//
//		// 距離
//		DirectX::XMVECTOR v = XMVectorSubtract(qVec, pVec);
//		float dist = XMVectorGetX(XMVector3Length(v));
//
//		float skin = 0.01f;
//
//		if (dist <= radius - skin)
//		{
//			result.hit = true;
//
//			float depth = radius - dist;
//
//			// AABB と同じ押し量
//			float push = depth * 0.7f;
//			push = max(push, 0.01f);
//
//			result.penetration = push;
//
//			// ? 法線（AABB と同じ向きに統一）
//			DirectX::XMVECTOR n;
//
//			if (dist > 0.0001f)
//			{
//				// AABB と同じ向き：center - p
//				DirectX::XMFLOAT3 dirOut =
//				{
//					center.x - p.x,
//					center.y - p.y,
//					center.z - p.z
//				};
//				n = XMVector3Normalize(XMLoadFloat3(&dirOut));
//			}
//			else
//			{
//				// fallback：XZ 方向優先
//				DirectX::XMFLOAT3 fallback =
//				{
//					center.x - p.x,
//					0.0f,
//					center.z - p.z
//				};
//
//				DirectX::XMVECTOR fb = XMLoadFloat3(&fallback);
//
//				if (XMVector3Length(fb).m128_f32[0] < 0.0001f)
//					fb = XMVectorSet(1, 0, 0, 0);
//
//				n = XMVector3Normalize(fb);
//			}
//
//			DirectX::XMStoreFloat3(&result.normal, n);
//			result.point = q;
//
//			return result;
//		}
//	}
//
//	return result;


//if (isRotating)
	//	return LaserHit();

LaserHit result;

float halfH = cylinder.GetHeight() * 0.5f;
float cylR = cylinder.GetRadius();
DirectX::XMFLOAT3 center = cylinder.GetCenter();

//下に引き伸ばしたい長さ
float downLength = 2.0f;

for (const auto& seg : segments)
{
	// ざっくり距離チェック（縦方向 minY のみ downLength 分広げる）
	float minX = min(seg.start.x, seg.end.x) - (cylR + radius);
	float maxX = max(seg.start.x, seg.end.x) + (cylR + radius);
	float minY = min(seg.start.y, seg.end.y) - (halfH + radius + downLength); // 下だけ拡張
	float maxY = max(seg.start.y, seg.end.y) + (halfH + radius);
	float minZ = min(seg.start.z, seg.end.z) - (cylR + radius);
	float maxZ = max(seg.start.z, seg.end.z) + (cylR + radius);

	if (center.x < minX || center.x > maxX ||
		center.y < minY || center.y > maxY ||
		center.z < minZ || center.z > maxZ)
	{
		continue;
	}

	DirectX::XMVECTOR s = XMLoadFloat3(&seg.start);
	DirectX::XMVECTOR e = XMLoadFloat3(&seg.end);

	DirectX::XMVECTOR segVec = XMVectorSubtract(e, s);
	float segLen = XMVectorGetX(XMVector3Length(segVec));
	if (segLen <= 0.0001f) continue;

	DirectX::XMVECTOR dir = XMVectorScale(segVec, 1.0f / segLen);

	// レーザー上の最近接点 p（元の中心線）
	DirectX::XMVECTOR c = XMLoadFloat3(&center);
	float t = XMVectorGetX(XMVector3Dot(XMVectorSubtract(c, s), dir));
	t = std::clamp(t, 0.0f, segLen);

	DirectX::XMVECTOR pVec = XMVectorAdd(s, XMVectorScale(dir, t));

	DirectX::XMFLOAT3 p;
	DirectX::XMStoreFloat3(&p, pVec);

	// Cylinder 上の最近接点 q
	DirectX::XMFLOAT3 q;

	// Y clamp
	q.y = std::clamp(p.y, center.y - halfH, center.y + halfH);

	// XZ 円
	float dx = p.x - center.x;
	float dz = p.z - center.z;
	float len = sqrtf(dx * dx + dz * dz);

	if (len > cylR)
	{
		q.x = center.x + dx / len * cylR;
		q.z = center.z + dz / len * cylR;
	}
	else
	{
		q.x = p.x;
		q.z = p.z;
	}

	// 横方向（XZ）の距離チェック（元の radius を維持）
	float distX4Z = sqrtf((q.x - p.x) * (q.x - p.x) + (q.z - p.z) * (q.z - p.z));

	// 縦方向（Y）の範囲チェック（上は radius、下は radius + downLength）
	float topY = p.y + radius;
	float bottomY = p.y - radius - downLength;

	float skin = 0.01f;

	// 横幅が radius 以内で、かつ縦方向の範囲に収まっているか
	if (distX4Z <= radius - skin && q.y >= bottomY && q.y <= topY)
	{
		result.hit = true;

		//上から乗ったか、横から接触したかを判定で切り分ける
		if (q.y >= p.y - skin)
		{
			// 【1】上から乗った場合の処理

			// 法線は真上（これでプレイヤー側は「上乗りのワープ」を実行する）
			result.normal = { 0.0f, 1.0f, 0.0f };

			// めり込み深さは上方向の深さ
			float depthY = topY - q.y;
			result.penetration = max(depthY * 0.7f, 0.01f);

			// プレイヤーが乗るべき実数値（レーザーの上面）
			/*DirectX::XMFLOAT3 floorPoint = p;
			floorPoint.y = seg.start.y + radius;
			result.point = floorPoint;*/
			DirectX::XMFLOAT3 floorPoint = p;
			floorPoint.y = p.y + radius;
			result.point = floorPoint;
		}
		else
		{
			//横から当たった場合の処理

			// 法線は横方向（XZ）のみ（Y成分は0にするため、プレイヤー側で「上乗り」は絶対に発生しない）
			DirectX::XMFLOAT3 dirXZ = { center.x - p.x, 0.0f, center.z - p.z };
			DirectX::XMVECTOR nXZ = DirectX::XMVector3Normalize(DirectX::XMLoadFloat3(&dirXZ));
			DirectX::XMStoreFloat3(&result.normal, nXZ);

			// もし完全に中心が重なって正規化できなかった場合の安全弁
			if (result.normal.x == 0.0f && result.normal.z == 0.0f) {
				result.normal = { 1.0f, 0.0f, 0.0f };
			}

			// めり込み深さは横方向の深さ
			float depthXZ = radius - distX4Z;
			result.penetration = max(depthXZ * 0.7f, 0.01f);

			// 交点はそのまま円柱上の点 q を使う（ワープさせない）
			result.point = q;
		}

		return result;
	}
}

return result;

}

void Laser::UpdateTransformByAngle(const DirectX::XMFLOAT3& center, float totalAngleY)
{
	DirectX::XMMATRIX rot = DirectX::XMMatrixRotationY(totalAngleY);
	DirectX::XMVECTOR c = DirectX::XMLoadFloat3(&center);

	// 1. ポジション：常に baseStartPos から計算
	DirectX::XMVECTOR basePos = DirectX::XMLoadFloat3(&baseStartPos);
	DirectX::XMVECTOR local = DirectX::XMVectorSubtract(basePos, c);
	local = DirectX::XMVector3Transform(local, rot);
	DirectX::XMVECTOR newPos = DirectX::XMVectorAdd(local, c);
	DirectX::XMStoreFloat3(&startPos, newPos);

	// 2. 方向：常に baseDirection から計算
	DirectX::XMVECTOR baseDir = DirectX::XMLoadFloat3(&baseDirection);
	DirectX::XMVECTOR newDir = DirectX::XMVector3TransformNormal(baseDir, rot);
	DirectX::XMStoreFloat3(&direction, newDir);


	currentAngleY = totalAngleY;
	// 3. Beam(LaserBeam) に最新の値を伝える
	beam.origin = startPos;
	beam.direction = direction;
}

void Laser::RotateAroundCenter(const DirectX::XMFLOAT3& center, float angleY)
{
	// origin を中心基準に移動
	DirectX::XMVECTOR pos = DirectX::XMLoadFloat3(&startPos);
	DirectX::XMVECTOR c = DirectX::XMLoadFloat3(&center);
	DirectX::XMVECTOR local = DirectX::XMVectorSubtract(pos, c);

	// Y軸回転
	DirectX::XMMATRIX rot = DirectX::XMMatrixRotationY(angleY);
	local = DirectX::XMVector3Transform(local, rot);

	// 中心に戻す
	DirectX::XMVECTOR newPos = DirectX::XMVectorAdd(local, c);
	DirectX::XMStoreFloat3(&startPos, newPos);

	// direction も回転
	DirectX::XMVECTOR dir = DirectX::XMLoadFloat3(&direction);
	dir = DirectX::XMVector3TransformNormal(dir, rot);
	DirectX::XMStoreFloat3(&direction, dir);
}

void Laser::Initialize(
	const DirectX::XMFLOAT3& emitterPos,
	const DirectX::XMFLOAT3& dir,
	float maxLen)
{
   model = std::make_unique<Model>("Data/Model/Objects/Laser/Laser.mdl");

   //beam.setEffect("Data/Effect/laserOre.efkefc");
   beam.setEffect("Data/Effect/reizar.efkefc","Data/Effect/laser_back.efkefc","Data/Effect/hansya.efkefc");

   // 最初に dir を正規化したものを baseDirection に入れる
   XMVECTOR v = XMVector3Normalize(XMLoadFloat3(&dir));
   XMStoreFloat3(&baseDirection, v); // ここで保存！

	baseStartPos = emitterPos;

	startPos = emitterPos;
	direction = baseDirection;
	maxLength = maxLen;
  
	scale = { 0.5f,0.5f,0.5f };

	
	//DirectX::XMVECTOR v = DirectX::XMLoadFloat3(&direction);
	//v = DirectX::XMVector3Normalize(v);
	//DirectX::XMStoreFloat3(&direction, v);


	// LaserBeam
	beam.origin = startPos;
	beam.direction = direction;
	beam.maxLength = maxLength;
	//beam.maxReflection = 5;
	//beam.radius = 0.3f;

   // OutputDebugStringA("laserやってる\n");
}

void Laser::Update(float elapsedTime)
{
	beam.isRotating = isRotating;


	if (!isActive) return;

  /*  Shoot();

	beam.SetPoints(startPos, endPos);
	beam.SetAngle(angle);
	beam.setDirection(direction);
	beam.Update(elapsedTime);*/

	position = startPos;

	//position.x -= direction.x*0.5f;
	angle.y = atan2f(direction.x, direction.z);

	UpdateTransform();

	// レーザーの位置
	beam.origin = startPos;
	beam.direction = direction;
	// LaserBeam がレーザーを撃つ（反射含む）
	beam.Update(elapsedTime);
}

void Laser::Render(const RenderContext& rc, ModelRenderer* renderer)
{
	if (!isActive) return;

	beam.Render();

	StageObject::Render(rc, renderer);
}

void Laser::SetRotating(bool flag)
{
	isRotating = flag;
}
