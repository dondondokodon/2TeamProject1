#include "JumpState.h"

#include"Player.h"

void JumpState::Initialize(Player& player)
{
	player.GetAnimation().PlayAnimation("Jump", false);
}

void JumpState::Finalize(Player& player)
{

}

//�X�V����
void JumpState::Update(Player& player, float elapsedTime, bool canControl)
{
	//�ړ����͏���
	player.InputMove(elapsedTime);

	if (player.getIsGround())
	{
		player.ChangeState(std::make_unique<IdleState>());
	}

	//�W�����v���͏���
	if (player.InputJump())
		player.ChangeState(std::make_unique<JumpState>());
}